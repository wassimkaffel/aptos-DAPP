module.exports = {
    mongoURI: process.env.MONOGDB_URI_LOCAL, // Insert your MongoDB connection URI here
    /* Example DB connection
      "mongodb://user_name:password@ds153752.mlab.com:53752/devconnector"

      */
    secretOrKey: "bearx" // Add your secret string or key here
};
