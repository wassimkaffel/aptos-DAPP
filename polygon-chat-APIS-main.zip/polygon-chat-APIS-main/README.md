#Buy and Sell USDT Restful APIs

## Available APIs details

### /v1/create-wallet

### /w3chat/v1/user-login/

### /w3chat/v1/set-user-profile/

### /w3chat/v1/get-user-profile/

### /w3chat/v1/friend/add_friend

### /w3chat/v1/friend/add_block

### /w3chat/v1/friend/add_favorite

### /w3chat/v1/friend/remove_friend

### /w3chat/v1/friend/remove_favorite

### /w3chat/v1/friend/remove_blocklist

### /w3chat/v1/friend/setFriendSentRequest

### /w3chat/v1/friend/Remove_Request

### /w3chat/v1/friend/getFriends

### /w3chat/v1/friend/getRequestFriends

### /w3chat/v1/friend/getsentRequestFriends

### /w3chat/v1/friend/getinviterequest

### /w3chat/v1/friend/getBlocklist

### /w3chat/v1/friend/getFavorite